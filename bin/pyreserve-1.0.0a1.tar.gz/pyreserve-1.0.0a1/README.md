# PyReserve
Create an empty Python package and reserve a name on PyPi with one command
